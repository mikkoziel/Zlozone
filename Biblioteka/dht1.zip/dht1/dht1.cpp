#include "dht1.h"

int dht1::read(int pin)
{
	//Bufor
	uint8_t bits[5];		//tablica wyników
	uint8_t cnt = 7;		//Licznik bitów
	uint8_t idx = 0;		//Licznik bajtów

	//Pusty bufor
	for (int i=0; i< 5; i++) bits[i] = 0;


	pinMode(pin, OUTPUT);
	digitalWrite(pin, LOW);
	delay(18);
	digitalWrite(pin, HIGH);
	delayMicroseconds(40);
	pinMode(pin, INPUT);

	// Czeka aż dostanie sygnał startu, jeśli nie dstanie to błąd czasowy
	unsigned int loopCnt = 10000;
	while(digitalRead(pin) == LOW)
		if (loopCnt-- == 0) return DHTLIB_ERROR_TIMEOUT;

	loopCnt = 10000;
	while(digitalRead(pin) == HIGH)
		if (loopCnt-- == 0) return DHTLIB_ERROR_TIMEOUT;

	// Czytamy odpowiedź sensora(40 bitów dzielimy na 5 bajtów wg dokumentacji)
	for (int i=0; i<40; i++)
	{
		loopCnt = 10000;
		while(digitalRead(pin) == LOW)
			if (loopCnt-- == 0) return DHTLIB_ERROR_TIMEOUT;

		unsigned long t = micros();	//zmienna do sprawdzenia czy przesyłanie trwało wystarczająco długo

		loopCnt = 10000;
		while(digitalRead(pin) == HIGH)
			if (loopCnt-- == 0) return DHTLIB_ERROR_TIMEOUT;

		if ((micros() - t) > 40) bits[idx] |= (1 << cnt);		//Uzupełnianie konkretnych pól tablicy bits przy użyciu przesuwania bitowego
																												//(jeśli czas przesyłania trwał przynajmniej 4ms wg dokumentacji)
		if (cnt == 0)   // Jeśli skończyliśmy uzupełniać wszystkie bity odpowiedniego bajtu
		{
			cnt = 7;    // restartujemy licznik bitowy
			idx++;      // przechodzimy do następnego bitu
		}
		else cnt--;	//Jeśli nie to kolenjy bit
	}

	// Przypisywanie do odpowiednich zmiennych
	humidity    = bits[0];		//odczyt wilgotności
	temperature = bits[2];		//oodczyt temperatury

	uint8_t sum = bits[0] + bits[1] + bits[2] + bits[3];	//zmienna do sprawdzenia sumy kontrolnej

	if (bits[4] != sum) return DHTLIB_ERROR_CHECKSUM;		//Jeśli suma kontrolna nie równa zmiennej to bład
	return DHTLIB_OK;		//Inaczej OK
}
